<?php
header('Content-Type: application/json');
require_once 'db_config.php';

$limit = intval($_GET['limit'] ?? 1000);
$limit = min($limit, 100000); // Maksimi 100000 tulosta

try {
    $stmt = $pdo->prepare("SELECT player_name, score, date_achieved FROM highscores ORDER BY score DESC LIMIT ?");
    $stmt->execute([$limit]);
    $scores = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode(['success' => true, 'scores' => $scores]);
} catch(PDOException $e) {
    echo json_encode(['success' => false, 'error' => 'Failed to fetch scores']);
}
?>