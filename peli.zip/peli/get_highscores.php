<?php
header('Content-Type: application/json');
require_once 'db_config.php';

$limit = isset($_GET['limit']) ? max(1, min(1000, (int)$_GET['limit'])) : 100;

try {
    $stmt = $pdo->prepare("SELECT player_name, score, date_achieved 
                           FROM highscores 
                           ORDER BY score DESC, date_achieved ASC 
                           LIMIT ?");
    $stmt->execute([$limit]);
    $scores = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode(['success' => true, 'scores' => $scores]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Query failed']);
}
?>