<?php
header('Content-Type: application/json');
require_once 'db_config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    
    $playerName = trim($data['player_name'] ?? '');
    $score = intval($data['score'] ?? 0);
    
    if (empty($playerName) || $score <= 0) {
        echo json_encode(['success' => false, 'error' => 'Invalid data']);
        exit;
    }
    
    // Rajoita nimen pituus
    $playerName = substr($playerName, 0, 50);
    
    try {
        $stmt = $pdo->prepare("INSERT INTO highscores (player_name, score) VALUES (?, ?)");
        $stmt->execute([$playerName, $score]);
        
        echo json_encode(['success' => true, 'id' => $pdo->lastInsertId()]);
    } catch(PDOException $e) {
        echo json_encode(['success' => false, 'error' => 'Failed to save score']);
    }
} else {
    echo json_encode(['success' => false, 'error' => 'Invalid request method']);
}
?>