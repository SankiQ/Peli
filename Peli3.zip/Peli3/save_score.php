<?php
header('Content-Type: application/json');
require_once 'db_config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Method not allowed']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);

$playerName = trim($data['player_name'] ?? '');
$score      = (int)($data['score'] ?? 0);

if ($playerName === '' || mb_strlen($playerName) > 30 || $score < 0) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Invalid data']);
    exit;
}

// Anti spammäys
$ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
$stmt = $pdo->prepare("SELECT COUNT(*) FROM highscores WHERE player_name = ? AND date_achieved > DATE_SUB(NOW(), INTERVAL 30 SECOND)");
$stmt->execute([$playerName]);
if ($stmt->fetchColumn() > 5) { 
    http_response_code(429);
    echo json_encode(['success' => false, 'error' => 'Too many requests']);
    exit;
}

try {
    $stmt = $pdo->prepare("INSERT INTO highscores (player_name, score, date_achieved) VALUES (?, ?, NOW())");
    $stmt->execute([$playerName, $score]);

    echo json_encode([
        'success' => true,
        'id'      => $pdo->lastInsertId(),
        'message' => 'Score saved!'
    ]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Save failed']);
}
?>