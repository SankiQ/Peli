const GAME_SETTINGS = {
  width: 800,
  height: 600,
  backgroundColor: 0x87ceeb,
  bulletSpeed: 500,
  fireRate: 250,
  soldierFallSpeed: 100,
  planeSpeed: 150,
  maxLanded: 5
};

const CONFIG = {
  type: Phaser.AUTO,
  width: GAME_SETTINGS.width,
  height: GAME_SETTINGS.height,
  backgroundColor: GAME_SETTINGS.backgroundColor,
  parent: 'game-container',
  physics: { default: 'arcade', arcade: { gravity: { y: 0 }, debug: false } },
  scene: { preload, create, update }
};
function preload(Pelitausta) {
  this.load.image('sky', 'Pelitausta.jpg'); 
}

function create() {
  this.add.image(GAME_SETTINGS.width/2, GAME_SETTINGS.height/2, 'sky')
      .setDisplaySize(GAME_SETTINGS.width, GAME_SETTINGS.height); 
}


new Phaser.Game(CONFIG);

function preload() {}

let cannon, bullets, planes, soldiers;
let cursors, lastFired = 0;
let score = 0, landed = 0, scoreText, landedText;

function create() {
  // Maaviiva
  this.add.line(0, GAME_SETTINGS.height - 30, 0, 0, GAME_SETTINGS.width, 0, 0xffffff).setOrigin(0);

  // Tykki
  const g = this.make.graphics({x:0, y:0, add:false});
  g.fillStyle(0xffffff);
  g.fillRect(-10,-20,20,40);
  g.fillCircle(0,0,15);
  g.generateTexture('cannon',40,40);
  cannon = this.add.sprite(GAME_SETTINGS.width/2, GAME_SETTINGS.height - 40, 'cannon').setOrigin(0.5,1);

  // Ammukset
  function preload(Luoti) {
  this.load.image('bullet', 'Luoti.avif'); 
}
  g.clear(); g.fillStyle(0xffff00); g.fillRect(0,0,4,10);
  g.generateTexture('bullet',4,10);
  bullets = this.physics.add.group();

  // Sotilaat ja lentokoneet
  g.clear(); g.fillStyle(0x00ffff); g.fillRect(0,0,40,10);
  g.generateTexture('plane',40,10);
  g.clear(); g.fillStyle(0xff6666); g.fillCircle(0,0,8);
  g.generateTexture('soldier',16,16);

  planes = this.physics.add.group();
  soldiers = this.physics.add.group();

  // UI
  scoreText = this.add.text(10,10,"Pisteet: 0",{font:'18px Arial',fill:'#fff'});
  landedText = this.add.text(10,30,"Maahan päässeet: 0",{font:'18px Arial',fill:'#ff6666'});

  // Ohjaimet
  cursors = this.input.keyboard.createCursorKeys();
  this.input.keyboard.on('keydown-SPACE', ()=>fire.call(this));

  // Lentokoneiden luonti
  this.time.addEvent({delay:2000, callback:()=>spawnPlane.call(this), loop:true});

  // Törmäykset
  this.physics.add.overlap(bullets, planes, onPlaneHit, null, this);
  this.physics.add.overlap(bullets, soldiers, onSoldierHit, null, this);
}

function update(time, delta) {
  if (cursors.left.isDown) cannon.x -= 3;
  if (cursors.right.isDown) cannon.x += 3;

  // Sotilaiden lasku ja maahan osuminen
  soldiers.getChildren().forEach(s=>{
    if (s.y >= GAME_SETTINGS.height - 30) {
      s.destroy();
      landed++;
      landedText.setText("Maahan päässeet: " + landed);
      if (landed >= GAME_SETTINGS.maxLanded) gameOver.call(this);
    }
  });
}

function fire() {
  const now = this.time.now;
  if (now - lastFired < GAME_SETTINGS.fireRate) return;
  lastFired = now;

  const bullet = bullets.create(cannon.x, cannon.y - 40, 'bullet');
  bullet.body.allowGravity = false;
  bullet.setVelocityY(-GAME_SETTINGS.bulletSpeed);
  this.time.addEvent({delay:2000, callback:()=>bullet.destroy()});
}

function spawnPlane() {
  const y = Phaser.Math.Between(50, 150);
  const fromLeft = Math.random() < 0.5;
  const x = fromLeft ? -40 : GAME_SETTINGS.width + 40;
  const plane = planes.create(x, y, 'plane');
  plane.body.allowGravity = false;
  plane.setVelocityX(fromLeft ? GAME_SETTINGS.planeSpeed : -GAME_SETTINGS.planeSpeed);
  plane.flipX = !fromLeft;

  // Pudota sotilas satunnaisesti
  this.time.addEvent({
    delay: Phaser.Math.Between(1000,2000),
    callback: ()=>{
      const soldier = soldiers.create(plane.x, plane.y + 10, 'soldier');
      soldier.setVelocityY(GAME_SETTINGS.soldierFallSpeed);
      soldier.body.allowGravity = false;
    },
    callbackScope:this
  });

  this.time.addEvent({delay:6000, callback:()=>plane.destroy()});
}

function onPlaneHit(bullet, plane) {
  bullet.destroy();
  plane.destroy();
  score += 50;
  scoreText.setText("Pisteet: " + score);
}

function onSoldierHit(bullet, soldier) {
  bullet.destroy();
  soldier.destroy();
  score += 20;
  scoreText.setText("Pisteet: " + score);
}

function gameOver() {
  this.physics.pause();
  this.add.text(GAME_SETTINGS.width/2, GAME_SETTINGS.height/2,
    "PELI OHI", {font:'48px Arial',fill:'#ffee88'}).setOrigin(0.5);
  this.add.text(GAME_SETTINGS.width/2, GAME_SETTINGS.height/2 + 40,
    "R - aloita uudelleen",{font:'18px Arial',fill:'#fff'}).setOrigin(0.5);
  this.input.keyboard.once('keydown-R', ()=>this.scene.restart());
}
